package com.tourismgov.service;

import com.tourismgov.dto.DashboardDTO;
import com.tourismgov.model.User;
import com.tourismgov.repository.DashboardRepository;
import com.tourismgov.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.LinkedHashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class DashboardServiceImpl implements DashboardService {

    private final DashboardRepository dashboardRepo;
    private final UserRepository userRepository;

    @Override
    public DashboardDTO getDashboardMetrics(String role, Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found with ID: " + userId));

        // SECURITY: Verify Role
        String dbRole = user.getRole().name().toUpperCase(); 
        if (!dbRole.equals(role.toUpperCase())) {
            throw new IllegalArgumentException("Access Denied: Role mismatch");
        }

        Map<String, Object> metrics = new LinkedHashMap<>();

        // 1. COMMON DATA (Everyone sees these)
        long totalS = dashboardRepo.countTotalSites();
        long activeS = dashboardRepo.countActiveHeritageSites();
        long unread = dashboardRepo.countMyUnreadNotifications(userId);

        metrics.put("totalHeritageSites", totalS);
        metrics.put("siteActivityPct", calculatePercentage(activeS, totalS) + "%");
        metrics.put("activeEvents", dashboardRepo.countActiveEvents());

        // 2. ROLE-SPECIFIC DATA
        switch (dbRole) {
            case "TOURIST":
               
                long totalB = dashboardRepo.countTotalBookingHistory(userId);
                long doneB = dashboardRepo.countCompletedByUserId(userId);
              
                metrics.put("tripCompletionRate", calculatePercentage(doneB, totalB) + "%");
                metrics.put("upcomingEvents", dashboardRepo.countUpcomingEvents(userId));
                break;

            default:
                // INTERNAL ROLES (Admin, Officer, Manager, Auditor, Compliance)
              
                metrics.put("totalUsers", dashboardRepo.countAllUsers());
                metrics.put("totalEvents", dashboardRepo.countAllEvents());
                metrics.put("totalBookings", dashboardRepo.countAllBookings());

                if (dbRole.equals("OFFICER")) {
                    metrics.put("pendingApprovals", dashboardRepo.countPendingBookingApprovals());
                    metrics.put("docsToVerify", dashboardRepo.countPendingDocValidations());
                } 
                else if (dbRole.equals("MANAGER") || dbRole.equals("ADMIN")) {
                    metrics.put("totalBudget", "₹" + dashboardRepo.sumTotalProgramBudget());
                    metrics.put("activePrograms", dashboardRepo.countActivePrograms());
                } 
                else if (dbRole.equals("COMPLIANCE") || dbRole.equals("AUDITOR")) {
                    metrics.put("policyViolations", dashboardRepo.countPolicyViolations());
                    metrics.put("pendingAudits", dashboardRepo.countPendingAudits());
                }
                break;
        }

        return DashboardDTO.builder()
                .role(dbRole)
                .userId(userId)
                .userName(user.getName())
                .metrics(metrics)
                .unreadNotifications(unread)
                .build();
    }

    private double calculatePercentage(long part, long total) {
        if (total <= 0) return 0.0;
        return Math.round((double) part / total * 100.0 * 10.0) / 10.0;
    }
}