package com.tourismgov.service;

import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import com.tourismgov.dto.TouristRequest;
import com.tourismgov.dto.TouristResponse;
import com.tourismgov.dto.NotificationRequestDTO;
import com.tourismgov.enums.NotificationCategory;
import com.tourismgov.enums.Status;
import com.tourismgov.model.Tourist;
import com.tourismgov.model.User;
import com.tourismgov.repository.TouristRepository;
import com.tourismgov.repository.UserRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
@RequiredArgsConstructor // Use this to avoid manual constructor
public class TouristServiceImpl implements TouristService {

    private final TouristRepository touristRepository;
    private final UserRepository userRepository; 
    private final NotificationService notificationService;
    private static final String TOURIST_NOT_FOUND = "Tourist profile not found";

    @Override
    @Transactional
    public TouristResponse createTourist(TouristRequest request) {
        log.info("Processing tourist profile for User ID: {}", request.getUserId());

        // 1. Check if profile exists
        Tourist tourist = touristRepository.findById(request.getUserId()).orElse(null);

        if (tourist == null) {
            log.info("Profile not found, initializing from User account...");
            User user = userRepository.findById(request.getUserId())
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found"));
            
            tourist = new Tourist();
            tourist.setUser(user); // Link Shared ID
            tourist.setName(user.getName()); // CRITICAL: Satisfy nullable = false
        }

        // 2. Map data
        request.apply(tourist);
        
        // Ensure name is never null if request.apply() wiped it
        if (tourist.getName() == null) {
            tourist.setName(tourist.getUser().getName());
        }
        
        tourist.setStatus(com.tourismgov.enums.Status.ACTIVE);
        
        // 3. Save and Flush
        // Using saveAndFlush ensures the DB confirms the write before we continue
        tourist = touristRepository.saveAndFlush(tourist);

        // 4. Notification
        sendNotification(tourist);

        return TouristResponse.toResponse(tourist);
    }

    private void sendNotification(Tourist tourist) {
        try {
            notificationService.create(NotificationRequestDTO.builder()
                    .userId(tourist.getUserId())
                    .entityId(tourist.getUserId())
                    .subject("Profile Completed")
                    .message("Hello " + tourist.getName() + ", your profile details have been saved.")
                    .category(NotificationCategory.TRANSACTIONAL)
                    .build());
        } catch (Exception e) {
            log.error("Notification failed: {}", e.getMessage());
        }
    }

    @Override
    @Transactional
    public TouristResponse updateTourist(Long userId, TouristRequest request) {
        Tourist tourist = touristRepository.findById(userId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, TOURIST_NOT_FOUND));
        
        request.apply(tourist);
        return TouristResponse.toResponse(touristRepository.save(tourist));
    }

    @Override
    @Transactional(readOnly = true)
    public TouristResponse getTouristById(Long userId) {
        return touristRepository.findById(userId)
                .map(TouristResponse::toResponse)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, TOURIST_NOT_FOUND));
    }

    @Override
    @Transactional(readOnly = true)
    public List<TouristResponse> getAllTourists() {
        return touristRepository.findAll().stream()
                .map(TouristResponse::toResponse)
                .toList();
    }
    
    @Override
    @Transactional
    public void deleteTourist(Long userId) {
        if (!touristRepository.existsById(userId)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, TOURIST_NOT_FOUND);
        }
        touristRepository.deleteById(userId);
    }
}