package com.tourismgov.service;

import com.tourismgov.dto.NotificationRequestDTO;
import com.tourismgov.dto.NotificationResponseDTO;
import com.tourismgov.model.Notification;
import com.tourismgov.model.User;
import com.tourismgov.enums.NotificationCategory;
import com.tourismgov.enums.NotificationStatus;
import com.tourismgov.enums.Role;
import com.tourismgov.exception.ResourceNotFoundException;
import com.tourismgov.repository.NotificationRepository;
import com.tourismgov.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.stream.Collectors;
@Slf4j
@Service
@RequiredArgsConstructor
public class NotificationServiceImpl implements NotificationService {

    private final NotificationRepository notificationRepository;
    private final UserRepository userRepository;
    private final EmailService emailService; 

    @Override
    @Transactional
    public NotificationResponseDTO create(NotificationRequestDTO request) {
        User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User", request.getUserId()));

        Notification notification = Notification.builder()
                .user(user)
                .entityId(request.getEntityId())
                .subject(request.getSubject())
                .message(request.getMessage())
                .category(request.getCategory())
                .status(NotificationStatus.UNREAD)
                .build();

        // STEP 1: Save and FORCE the database write immediately
        Notification savedNotification = notificationRepository.saveAndFlush(notification);

        // STEP 2: Wrap the email in a TRY-CATCH inside this method
        try {
            // This is the "Dangerous" part that might fail
            emailService.sendNotificationEmail(user.getEmail(), user.getName(), request.getSubject(), request.getMessage());
        } catch (Exception e) {
           
            log.error("EMAIL FAILED for user {}: {}. Notification is still saved in DB.", 
                      user.getEmail(), e.getMessage());
        }

        return toDTO(savedNotification);
    }

    @Override
    @Transactional
    public void sendGlobalNotification(NotificationRequestDTO request) {
        // 1. Validate the Sender
        User sender = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User", request.getUserId()));
        if (sender.getRole() == Role.TOURIST) { 
                    log.warn("Security Alert: User {} (TOURIST) attempted to send a global broadcast.", sender.getUserId());
                    throw new ResponseStatusException(
                        HttpStatus.FORBIDDEN, 
                        "Access Denied: Tourists are not authorized to send global announcements."
                    );
                }
        // 2. Fetch all recipients
        List<User> allUsers = userRepository.findAll();
        log.info("Starting Global Broadcast for {} users.", allUsers.size());

        // 3. Create the Database records
        List<Notification> batch = allUsers.stream()
            .map(user -> Notification.builder()
                .user(user)
                .subject(request.getSubject())
                .message(request.getMessage())
                .category(request.getCategory())
                .entityId(request.getEntityId() != null ? request.getEntityId() : 0L)
                .status(NotificationStatus.UNREAD)
                .build())
            .toList();

        notificationRepository.saveAll(batch);
        notificationRepository.flush(); // Ensure all notifications exist in DB before emailing

       
        allUsers.forEach(user -> sendEmailSafely(user, request.getSubject(), request.getMessage()));
        
        log.info("Global Broadcast completed successfully.");
    }

   
    private void sendEmailSafely(User user, String subject, String message) {
        try {
            emailService.sendNotificationEmail(user.getEmail(), user.getName(), subject, message);
        } catch (Exception e) {
            // If you see this in your console, your Java logic worked but your SMTP failed
            log.error("EMAIL FAILED for user {}: {}. Database notification is still saved.", 
                      user.getEmail(), e.getMessage());
        }
    }

    @Override
    @Transactional(readOnly = true)
    public List<NotificationResponseDTO> getAll(Long userId) {
        verifyUserExists(userId);
        return notificationRepository.findByUser_UserIdOrderByCreatedDateDesc(userId) 
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<NotificationResponseDTO> getUnread(Long userId) {
        verifyUserExists(userId);
        return notificationRepository
                .findByUser_UserIdAndStatusOrderByCreatedDateDesc(userId, NotificationStatus.UNREAD)
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public NotificationResponseDTO markAsRead(Long notificationId, Long userId) {
        Notification notification = notificationRepository
                .findByNotificationIdAndUser_UserId(notificationId, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Notification", notificationId));

        notification.setStatus(NotificationStatus.READ);
        return toDTO(notificationRepository.save(notification));
    }

    @Override
    @Transactional(readOnly = true)
    public List<NotificationResponseDTO> getByCategory(Long userId, NotificationCategory category) {
        verifyUserExists(userId);
        return notificationRepository
                .findByUser_UserIdAndCategoryOrderByCreatedDateDesc(userId, category)
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    private void verifyUserExists(Long userId) {
        if (!userRepository.existsById(userId)) {
            throw new ResourceNotFoundException("User", userId);
        }
    }

    private NotificationResponseDTO toDTO(Notification notification) {
        return NotificationResponseDTO.builder()
                .notificationId(notification.getNotificationId())
                .userId(notification.getUser().getUserId())
                .userName(notification.getUser().getName())
                .entityId(notification.getEntityId())
                .subject(notification.getSubject())
                .message(notification.getMessage())
                .category(notification.getCategory())
                .status(notification.getStatus())
                .createdDate(notification.getCreatedDate())
                .build();
    }
}