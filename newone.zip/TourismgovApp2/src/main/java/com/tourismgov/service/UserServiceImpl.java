package com.tourismgov.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tourismgov.dto.UserRequest;
import com.tourismgov.dto.UserResponse;
import com.tourismgov.enums.Role;
import com.tourismgov.model.User;
import com.tourismgov.model.Tourist;
import com.tourismgov.repository.UserRepository;
import com.tourismgov.repository.TouristRepository;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@Transactional(readOnly = true)
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final TouristRepository touristRepository; 
    private final PasswordEncoder passwordEncoder;

    public UserServiceImpl(UserRepository userRepository, 
                           TouristRepository touristRepository, 
                           PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.touristRepository = touristRepository;
        this.passwordEncoder = passwordEncoder;
    }

    private User mapToEntityAndSave(UserRequest request) {
        User user = new User();
        if (request.getUserId() != null) {
            user.setUserId(request.getUserId());
        }
        user.setName(request.getName());
        
        // Convert string role to Enum safely
        Role assignedRole = Role.valueOf(request.getRole().toUpperCase());
        user.setRole(assignedRole);
        
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword())); 
        user.setPhone(request.getPhone());
        user.setStatus(request.getStatus() != null ? request.getStatus() : "ACTIVE");
        
        // 1. SAVE AND FLUSH USER
        User savedUser = userRepository.saveAndFlush(user);
        log.info("User saved with ID: {} and Role: {}", savedUser.getUserId(), savedUser.getRole());

        // 2. FORCE CHECK: Use the assignedRole variable to avoid Proxy issues
        if (assignedRole == Role.TOURIST) {
            log.info("MATCH: Creating Tourist profile for User ID: {}", savedUser.getUserId());
            
            try {
                Tourist tourist = new Tourist();
                tourist.setUser(savedUser); // @MapsId links to savedUser.userId
                tourist.setName(savedUser.getName()); 
                
                // MAPPING PHONE AND STATUS
                tourist.setContactInfo(savedUser.getPhone()); 
                tourist.setStatus(com.tourismgov.enums.Status.ACTIVE);
                
                // 3. SAVE AND FLUSH TOURIST
                touristRepository.saveAndFlush(tourist);
                log.info("SUCCESS: Tourist profile persisted for ID: {}", savedUser.getUserId());
            } catch (Exception e) {
                log.error("FAILURE: Database rejected Tourist insert: {}", e.getMessage());
                throw e; // Rethrow to rollback User save if Tourist fails
            }
        } else {
            log.warn("SKIP: Role is {}, not TOURIST. No profile created.", assignedRole);
        }
        
        return savedUser;
    }

    @Override
    @Transactional
    public User create(UserRequest request) {
        return mapToEntityAndSave(request);
    }

    @Override
    @Transactional
    public List<User> createAll(List<UserRequest> requests) {
        List<User> savedUsers = new ArrayList<>();
        for (UserRequest r : requests) {
            savedUsers.add(mapToEntityAndSave(r));
        }
        return savedUsers;
    }
    
    @Override
    @Transactional
    public UserResponse registerUser(UserRequest request) {
        User user = mapToEntityAndSave(request);
        return toResponse(user);
    }

    @Override
    public UserResponse toResponse(User user) {
        UserResponse dto = new UserResponse();
        dto.setUserId(user.getUserId());
        dto.setName(user.getName());
        dto.setRole(user.getRole().name());
        dto.setEmail(user.getEmail());
        dto.setPhone(user.getPhone());
        dto.setStatus(user.getStatus());
        return dto;
    }
}