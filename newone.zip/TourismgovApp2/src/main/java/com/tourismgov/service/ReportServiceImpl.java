package com.tourismgov.service;

import com.tourismgov.dto.ReportRequestDTO;
import com.tourismgov.dto.ReportSummaryDTO;
import com.tourismgov.enums.ReportScope;
import com.tourismgov.model.*;
import com.tourismgov.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class ReportServiceImpl implements ReportService {

    private final ReportRepository reportRepo;
    private final UserRepository userRepo;
    private final HeritageSiteRepository siteRepo;
    private final EventRepository eventRepo;
    private final TourismProgramRepository programRepo;
    private final ComplianceRecordRepository complianceRepo;

    @Override
    @Transactional
    public ReportSummaryDTO generateReport(ReportRequestDTO request) {
        User requester = userRepo.findById(request.getRequesterId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found"));

        if (requester.getRole() == com.tourismgov.enums.Role.TOURIST) {
            throw new ResponseStatusException(
                HttpStatus.FORBIDDEN, 
                "Access Denied: Tourists are not authorized to generate government reports."
            );
        }

        StringBuilder reportData = new StringBuilder();
        reportData.append("--- OFFICIAL DATA LOG ---\n\n");

        switch (request.getScope()) {
            case SITE -> {
                List<HeritageSite> sites = siteRepo.findAll();
                for (HeritageSite s : sites) {
                    reportData.append("SiteID: ").append(s.getSiteId())
                              .append(" | Name: ").append(s.getName())
                              .append(" | Location: ").append(s.getLocation())
                              .append(" | Status: ").append(s.getStatus())
                              .append(" | Description: ").append(s.getDescription()).append("\n");
                }
            }
            case EVENT -> {
                List<Event> events = eventRepo.findAll();
                for (Event e : events) {
                    reportData.append("EventID: ").append(e.getEventId())
                              .append(" | Title: ").append(e.getTitle())
                              .append(" | Location: ").append(e.getLocation())
                              .append(" | Date: ").append(e.getDate())
                              .append(" | Status: ").append(e.getStatus()).append("\n");
                }
            }
            case PROGRAM -> {
                List<TourismProgram> programs = programRepo.findAll();
                for (TourismProgram p : programs) {
                    reportData.append("ProgramID: ").append(p.getProgramId())
                              .append(" | Title: ").append(p.getTitle())
                              .append(" | Budget: INR ").append(p.getBudget())
                              .append(" | Start: ").append(p.getStartDate())
                              .append(" | End: ").append(p.getEndDate())
                              .append(" | Status: ").append(p.getStatus()).append("\n");
                }
            }
            case COMPLIANCE -> {
                List<ComplianceRecord> records = complianceRepo.findAll();
                for (ComplianceRecord c : records) {
                    reportData.append("AuditID: ").append(c.getComplianceId())
                              .append(" | EntityID: ").append(c.getEntityId())
                              .append(" | Type: ").append(c.getType())
                              .append(" | Result: ").append(c.getResult())
                              .append(" | Notes: ").append(c.getNotes()).append("\n");
                }
            }
        }

        Report savedReport = reportRepo.save(Report.builder()
                .scope(request.getScope())
                .metrics(reportData.toString())
                .generatedBy(requester)
                .generatedDate(LocalDateTime.now())
                .build());

        return ReportSummaryDTO.builder()
                .reportId(savedReport.getReportId())
                .scope(savedReport.getScope())
                .generatedDate(savedReport.getGeneratedDate())
                .generatedByName(savedReport.getGeneratedBy().getName())
                .generatedByUserId(savedReport.getGeneratedBy().getUserId())
                .generatedByRole(savedReport.getGeneratedBy().getRole().name())
                .metrics(savedReport.getMetrics()) 
                .build();
    }

    @Override
    @Transactional(readOnly = true)
    public List<ReportSummaryDTO> getReportHistory(Long userId, ReportScope scope, LocalDate searchDate) {
        userRepo.findById(userId).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found"));

        LocalDateTime start = null;
        LocalDateTime end = null;
        
        if (searchDate != null) {
            start = searchDate.atStartOfDay();      
            end = searchDate.atTime(23, 59, 59);    
        }

        List<Report> myReports = reportRepo.findMyReports(userId, scope, start, end);

        return myReports.stream().map(report -> ReportSummaryDTO.builder()
                .reportId(report.getReportId())
                .scope(report.getScope())
                .generatedDate(report.getGeneratedDate())
                .generatedByName(report.getGeneratedBy().getName())
             
                .generatedByUserId(report.getGeneratedBy().getUserId())
                .generatedByRole(report.getGeneratedBy().getRole().name())
                .metrics(report.getMetrics())
                .build())
                .collect(Collectors.toList());
    }
}