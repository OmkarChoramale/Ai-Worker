package com.tourismgov.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import static com.tourismgov.exception.ErrorMessages.RECORD_NOT_FOUND;
import com.tourismgov.dto.ComplianceRecordDto;
import com.tourismgov.dto.ComplianceRequest;
import com.tourismgov.dto.NotificationRequestDTO; // ADDED
import com.tourismgov.enums.NotificationCategory; // ADDED
import com.tourismgov.model.ComplianceRecord;
import com.tourismgov.repository.ComplianceRecordRepository;
import com.tourismgov.security.SecurityService; // ADDED
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j 
@Transactional(readOnly = true)
public class ComplianceServiceImpl implements ComplianceService {

    private final ComplianceRecordRepository complianceRepository;
    private final AuditLogService auditLogService;
    private final SecurityService securityService; // INJECTED
    private final NotificationService notificationService; // INJECTED

    @Override
    @Transactional
    public ComplianceRecordDto createComplianceCheck(ComplianceRequest request) {
        log.info("Creating compliance record for: {}", request.getReferenceNumber());
        
        ComplianceRecord record = new ComplianceRecord();
        record.setReferenceNumber(request.getReferenceNumber());
        record.setEntityId(request.getEntityId());
        record.setType(request.getComplianceType().toUpperCase());
        record.setNotes(request.getDescription());
        record.setResult("PENDING");

        ComplianceRecord saved = complianceRepository.save(record);
        
        // Use SecurityService to get the actual officer ID automatically
        Long currentOfficerId = securityService.getCurrentUserId();
        auditLogService.recordAction(currentOfficerId, "COMPLIANCE_CREATED", "REF_" + saved.getReferenceNumber());
        
        return mapToComplianceDto(saved);
    }

    @Override
    @Transactional
    public ComplianceRecordDto updateComplianceResult(Long recordId, String result, Long officerId) {
        ComplianceRecord record = complianceRepository.findById(recordId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, RECORD_NOT_FOUND));
                
        record.setResult(result.toUpperCase());
        ComplianceRecord updated = complianceRepository.save(record);
        
        // Get dynamic actor ID for audit and notification permission
        Long actorId = securityService.getCurrentUserId();
        auditLogService.recordAction(actorId, "COMPLIANCE_UPDATED", "REF_" + record.getReferenceNumber());

        // --- NOTIFICATION: BROADCAST COMPLIANCE RESULT ---
        notificationService.sendGlobalNotification(NotificationRequestDTO.builder()
                .userId(actorId) // Sender ID for role verification
                .entityId(updated.getComplianceId())
                .subject("Compliance Update: " + updated.getReferenceNumber())
                .message("Compliance check for " + updated.getType() + " has been finalized with result: " + updated.getResult())
                .category(NotificationCategory.SYSTEM_UPDATE)
                .build());
        
        return mapToComplianceDto(updated);
    }

    // --- OTHER METHODS (NO LOGIC CHANGES) ---

    @Override
    public Page<ComplianceRecordDto> getAllComplianceRecords(Pageable pageable) {
        return complianceRepository.findAll(pageable).map(this::mapToComplianceDto);
    }
    
    @Override
    public ComplianceRecordDto getComplianceRecordById(Long recordId) {
        return complianceRepository.findById(recordId)
                .map(this::mapToComplianceDto)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, RECORD_NOT_FOUND));
    }
    
    @Override
    @Transactional
    public void deleteComplianceRecord(Long recordId) {
        ComplianceRecord record = complianceRepository.findById(recordId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, RECORD_NOT_FOUND));
        complianceRepository.delete(record);
    }

    private ComplianceRecordDto mapToComplianceDto(ComplianceRecord r) {
        return ComplianceRecordDto.builder()
                .complianceId(r.getComplianceId())
                .referenceNumber(r.getReferenceNumber())
                .entityId(r.getEntityId())
                .entityType(r.getType())
                .result(r.getResult())
                .date(r.getCreatedAt()) 
                .notes(r.getNotes())
                .build();
    }
}