package com.tourismgov.service;

import com.tourismgov.dto.BookingRequest;
import com.tourismgov.dto.BookingResponse;
import com.tourismgov.dto.NotificationRequestDTO;
import com.tourismgov.enums.NotificationCategory;
import com.tourismgov.model.Booking;
import com.tourismgov.model.Event;
import com.tourismgov.model.Tourist;
import com.tourismgov.repository.BookingRepository;
import com.tourismgov.repository.EventRepository;
import com.tourismgov.repository.TouristRepository;
import com.tourismgov.security.SecurityService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class BookingServiceImpl implements BookingService {

    private final BookingRepository bookingRepository;
    private final EventRepository eventRepository;
    private final TouristRepository touristRepository;
    private final NotificationService notificationService;
    private final SecurityService securityService;

    @Override
    @Transactional
    public BookingResponse createBooking(Long eventId, BookingRequest request) {
        // FIXED: Using userId from request as the key
        log.info("Creating new booking for Event ID: {} for User ID: {}", eventId, request.getUserId());

        Event event = eventRepository.findById(eventId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Event not found"));
                
        // FIXED: Tourist is now identified by userId
        Tourist tourist = touristRepository.findById(request.getUserId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Tourist profile not found"));

        Booking booking = new Booking();
        booking.setEvent(event);
        booking.setTourist(tourist);
        booking.setDate(LocalDateTime.now());
        booking.setStatus("CONFIRMED");

        Booking savedBooking = bookingRepository.save(booking);
        
        // --- NOTIFICATION: SAFE BLOCK ---
        try {
            notificationService.create(NotificationRequestDTO.builder()
                    .userId(tourist.getUserId()) // Recipient: The Tourist (using shared ID)
                    .entityId(savedBooking.getBookingId())
                    .subject("Booking Confirmed: " + event.getTitle())
                    .message("Hello " + tourist.getName() + ", your booking for '" + event.getTitle() + "' is confirmed.")
                    .category(NotificationCategory.TRANSACTIONAL)
                    .build());
        } catch (Exception e) {
            log.error("Transactional notification failed: {}", e.getMessage());
        }

        return mapToResponse(savedBooking);
    }

    @Override
    @Transactional
    public BookingResponse updateBookingStatus(Long bookingId, BookingRequest request) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Booking not found"));

        if (request.getStatus() != null && !request.getStatus().isBlank()) {
            booking.setStatus(request.getStatus().toUpperCase());
        }

        Booking updated = bookingRepository.save(booking);

        // --- NOTIFICATION: STATUS CHANGE ALERT ---
        try {
            notificationService.create(NotificationRequestDTO.builder()
                    .userId(updated.getTourist().getUserId()) 
                    .entityId(updated.getBookingId())
                    .subject("Booking Status Updated")
                    .message("Your booking for " + updated.getEvent().getTitle() + " is now " + updated.getStatus())
                    .category(NotificationCategory.TRANSACTIONAL)
                    .build());
        } catch (Exception e) {
            log.error("Status notification failed: {}", e.getMessage());
        }

        return mapToResponse(updated);
    }

    @Override
    public BookingResponse getBookingById(Long bookingId) {
        return bookingRepository.findById(bookingId)
                .map(this::mapToResponse)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Booking not found"));
    }

    @Override
    public List<BookingResponse> getBookingsByEvent(Long eventId) {
        if (!eventRepository.existsById(eventId)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Event not found");
        }
        return bookingRepository.findByEvent_EventId(eventId).stream().map(this::mapToResponse).toList();
    }

    @Override
    public List<BookingResponse> getBookingsByTourist(Long userId) {
        // FIXED: Using userId as the identifier
        if (!touristRepository.existsById(userId)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Tourist not found");
        }
        // Ensure your BookingRepository method is named correctly: findByTourist_UserId
        return bookingRepository.findByTourist_UserId(userId).stream().map(this::mapToResponse).toList();
    }

    @Override
    public Page<BookingResponse> getAllBookingsPaged(String status, int page, int size) {
        return bookingRepository.findAll(PageRequest.of(page, size)).map(this::mapToResponse);
    }

    @Override
    public Page<BookingResponse> getBookingsByEventPaged(Long eventId, int page, int size) {
        return bookingRepository.findByEvent_EventId(eventId, PageRequest.of(page, size)).map(this::mapToResponse);
    }

    private BookingResponse mapToResponse(Booking booking) {
        BookingResponse response = new BookingResponse();
        response.setBookingId(booking.getBookingId());
        if (booking.getTourist() != null) {
            // FIXED: setter name changed from setTouristId to setUserId to match DTO update
            response.setUserId(booking.getTourist().getUserId());
        }
        if (booking.getEvent() != null) {
            response.setEventId(booking.getEvent().getEventId());
        }
        response.setDate(booking.getDate());
        response.setStatus(booking.getStatus());
        return response;
    }
}