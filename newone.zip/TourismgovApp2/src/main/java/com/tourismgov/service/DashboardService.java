package com.tourismgov.service;

import com.tourismgov.dto.DashboardDTO;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;


public interface DashboardService {

  
    DashboardDTO getDashboardMetrics(
        @NotBlank(message = "Role is required") String role, 
        @NotNull(message = "User ID is required") Long userId
    );
}