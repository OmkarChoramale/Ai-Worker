package com.tourismgov.service;

import com.tourismgov.dto.AuthRequest;
import com.tourismgov.dto.AuthResponse;
import com.tourismgov.dto.NotificationRequestDTO;
import com.tourismgov.dto.UserRequest;
import com.tourismgov.dto.UserResponse;
import com.tourismgov.enums.NotificationCategory;
import com.tourismgov.enums.Role;
import com.tourismgov.enums.Gender; // Added Import
import com.tourismgov.model.User;
import com.tourismgov.model.Tourist; 
import com.tourismgov.repository.UserRepository;
import com.tourismgov.repository.TouristRepository; 
import com.tourismgov.security.JwtUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate; // Added Import

@Slf4j
@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final UserRepository userRepository;
    private final TouristRepository touristRepository; 
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final UserDetailsService userDetailsService;
    private final JwtUtil jwtUtil;
    private final NotificationService notificationService;

    @Override
    @Transactional
    public UserResponse registerUser(UserRequest request) {
        if (userRepository.findByEmail(request.getEmail()).isPresent()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Email already in use");
        }

        // 1. Map and Save User
        User user = new User();
        user.setName(request.getName());
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setPhone(request.getPhone());
        
        Role assignedRole = Role.valueOf(request.getRole().toUpperCase());
        user.setRole(assignedRole);
        user.setStatus("ACTIVE");

        // Force Flush to ensure ID is generated before Tourist uses it
        User savedUser = userRepository.saveAndFlush(user);

        // 2. CRITICAL FIX: Map all Tourist fields to avoid NULL values
        if (assignedRole == Role.TOURIST) {
            log.info("Creating Tourist profile for User: {}", savedUser.getName());
            
            Tourist tourist = new Tourist();
            tourist.setUser(savedUser); // Links Shared ID via @MapsId
            tourist.setName(savedUser.getName()); 
            tourist.setContactInfo(savedUser.getPhone()); 
            
            // --- NEW MAPPINGS TO AVOID NULL ---
            tourist.setAddress(request.getAddress());
            
            if (request.getDob() != null && !request.getDob().isBlank()) {
                try {
                    // Converts "YYYY-MM-DD" string to LocalDate
                    tourist.setDob(LocalDate.parse(request.getDob()));
                } catch (Exception e) {
                    log.warn("Invalid DOB format: {}. Expected YYYY-MM-DD", request.getDob());
                }
            }
            
            if (request.getGender() != null && !request.getGender().isBlank()) {
                try {
                    // Converts String to Gender Enum
                    tourist.setGender(Gender.valueOf(request.getGender().toUpperCase()));
                } catch (Exception e) {
                    log.warn("Invalid Gender value: {}", request.getGender());
                }
            }
            
            // Optional: Map nationality and passportNumber if they exist in your Tourist model
            // tourist.setNationality(request.getNationality());
            // tourist.setPassportNumber(request.getPassportNumber());

            tourist.setStatus(com.tourismgov.enums.Status.ACTIVE);
            
            touristRepository.saveAndFlush(tourist);
            log.info("Tourist table successfully updated with Address, DOB, and Gender.");
        }

        // 3. Notification Block
        try {
            notificationService.create(NotificationRequestDTO.builder()
                    .userId(savedUser.getUserId())
                    .entityId(savedUser.getUserId())
                    .subject("Welcome to TourismGov!")
                    .message("Hello " + savedUser.getName() + ", your account has been created successfully.")
                    .category(NotificationCategory.TRANSACTIONAL)
                    .build());
        } catch (Exception e) {
            log.error("Welcome notification failed: {}", e.getMessage());
        }

        return mapToUserResponse(savedUser);
    }

    @Override
    public AuthResponse loginUser(AuthRequest request) {
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword())
        );

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found"));

        if (!"ACTIVE".equalsIgnoreCase(user.getStatus())) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Account is not active");
        }

        final UserDetails userDetails = userDetailsService.loadUserByUsername(request.getEmail());
        final String jwt = jwtUtil.generateToken(userDetails);

        return new AuthResponse(jwt, user.getUserId(), user.getRole().name(), user.getName());
    }

    private UserResponse mapToUserResponse(User user) {
        UserResponse dto = new UserResponse();
        dto.setUserId(user.getUserId());
        dto.setName(user.getName());
        dto.setRole(user.getRole().name());
        dto.setEmail(user.getEmail());
        dto.setPhone(user.getPhone());
        dto.setStatus(user.getStatus());
        return dto;
    }
}