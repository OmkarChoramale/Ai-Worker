package com.tourismgov.service;

import com.tourismgov.dto.*;
import com.tourismgov.enums.NotificationCategory;
import com.tourismgov.model.Resource;
import com.tourismgov.model.TourismProgram;
import com.tourismgov.repository.ResourceRepository;
import com.tourismgov.repository.TourismProgramRepository;
import com.tourismgov.security.SecurityService; // ADDED
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class TourismProgramServiceImpl implements TourismProgramService {

    private static final String PROGRAM_NOT_FOUND = "Program not found";

    private final TourismProgramRepository programRepository;
    private final ResourceRepository resourceRepository;
    private final NotificationService notificationService; // INJECTED
    private final SecurityService securityService; // INJECTED

    @Override
    @Transactional
    public ProgramResponse createProgram(ProgramRequest request) {
        log.info("Creating new Tourism Program: {}", request.getTitle());
        
        TourismProgram program = new TourismProgram();
        program.setTitle(request.getTitle());
        program.setDescription(request.getDescription());
        program.setStartDate(request.getStartDate());
        program.setEndDate(request.getEndDate());
        program.setBudget(request.getBudget());
        program.setStatus("PLANNED");

        TourismProgram savedProgram = programRepository.save(program);

        // --- GLOBAL NOTIFICATION: NEW PROGRAM ---
        Long actorId = securityService.getCurrentUserId();
        notificationService.sendGlobalNotification(NotificationRequestDTO.builder()
                .userId(actorId)
                .entityId(savedProgram.getProgramId())
                .subject("New Tourism Program Launched")
                .message("A new program '" + savedProgram.getTitle() + "' has been initiated.")
                .category(NotificationCategory.ANNOUNCEMENT)
                .build());

        return mapToProgramResponse(savedProgram);
    }

    @Override
    @Transactional
    public ProgramResponse updateProgramStatus(Long programId, String status) {
        TourismProgram program = programRepository.findById(programId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, PROGRAM_NOT_FOUND));
        
        program.setStatus(status.toUpperCase());
        TourismProgram saved = programRepository.save(program);

        // --- GLOBAL NOTIFICATION: STATUS UPDATE ---
        Long actorId = securityService.getCurrentUserId();
        notificationService.sendGlobalNotification(NotificationRequestDTO.builder()
                .userId(actorId)
                .entityId(saved.getProgramId())
                .subject("Program Update: " + saved.getTitle())
                .message("The status of '" + saved.getTitle() + "' is now " + saved.getStatus())
                .category(NotificationCategory.SYSTEM_UPDATE)
                .build());

        return mapToProgramResponse(saved);
    }

    @Override
    @Transactional
    public ResourceResponse allocateResourceToProgram(Long programId, ResourceRequest request) {
        TourismProgram program = programRepository.findById(programId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, PROGRAM_NOT_FOUND));

        Resource resource = new Resource();
        resource.setProgram(program);
        resource.setType(request.getType().toUpperCase());
        resource.setQuantity(request.getQuantity());
        resource.setStatus("ALLOCATED");

        Resource savedResource = resourceRepository.save(resource);

        // --- GLOBAL NOTIFICATION: RESOURCE ALLOCATION ---
        Long actorId = securityService.getCurrentUserId();
        notificationService.sendGlobalNotification(NotificationRequestDTO.builder()
                .userId(actorId)
                .entityId(savedResource.getResourceId())
                .subject("Resource Allocation: " + program.getTitle())
                .message("New " + savedResource.getType() + " resources have been allocated to the program.")
                .category(NotificationCategory.SYSTEM_UPDATE)
                .build());

        return mapToResourceResponse(savedResource);
    }

    // --- REMAINING METHODS UNCHANGED ---

    @Override
    public ProgramResponse getProgramById(Long programId) {
        return programRepository.findById(programId)
                .map(this::mapToProgramResponse)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, PROGRAM_NOT_FOUND));
    }

    @Override
    public List<ProgramResponse> getAllPrograms() {
        return programRepository.findAll().stream().map(this::mapToProgramResponse).toList();
    }

    @Override
    public Page<ProgramResponse> getProgramsPaged(int page, int size) {
        return programRepository.findAll(PageRequest.of(page, size)).map(this::mapToProgramResponse);
    }

    @Override
    @Transactional
    public ProgramResponse updateProgram(Long programId, ProgramRequest request) {
        TourismProgram program = programRepository.findById(programId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, PROGRAM_NOT_FOUND));
        program.setTitle(request.getTitle());
        program.setDescription(request.getDescription());
        program.setStartDate(request.getStartDate());
        program.setEndDate(request.getEndDate());
        program.setBudget(request.getBudget());
        return mapToProgramResponse(programRepository.save(program));
    }

    @Override
    @Transactional
    public void deleteProgram(Long programId) {
        TourismProgram program = programRepository.findById(programId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, PROGRAM_NOT_FOUND));
        programRepository.delete(program);
    }

    @Override
    @Transactional
    public ResourceResponse updateResourceStatus(Long resourceId, String status) {
        Resource resource = resourceRepository.findById(resourceId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Resource not found"));
        resource.setStatus(status.toUpperCase());
        return mapToResourceResponse(resourceRepository.save(resource));
    }

    @Override
    public List<ResourceResponse> getResourcesByProgram(Long programId) {
        if (!programRepository.existsById(programId)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, PROGRAM_NOT_FOUND);
        }
        return resourceRepository.findByProgram_ProgramId(programId).stream()
                .map(this::mapToResourceResponse)
                .toList();
    }

    @Override
    @Transactional
    public void deleteResource(Long resourceId) {
        Resource resource = resourceRepository.findById(resourceId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Resource not found"));
        resourceRepository.delete(resource);
    }

    @Override
    public Map<String, Object> getBudgetReport(Long programId) {
        TourismProgram program = programRepository.findById(programId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, PROGRAM_NOT_FOUND));
        List<Resource> resources = resourceRepository.findByProgram_ProgramId(programId);
        double totalSpent = resources.stream()
                .filter(r -> "FUNDS".equalsIgnoreCase(r.getType()))
                .mapToDouble(Resource::getQuantity)
                .sum();
        double budget = program.getBudget() != null ? program.getBudget() : 0.0;
        double remaining = budget - totalSpent;
        return Map.of(
            "programTitle", program.getTitle(),
            "allocatedBudget", budget,
            "totalFundsSpent", totalSpent,
            "remainingBudget", remaining,
            "isOverBudget", totalSpent > budget
        );
    }

    private ProgramResponse mapToProgramResponse(TourismProgram program) {
        ProgramResponse response = new ProgramResponse();
        response.setProgramId(program.getProgramId());
        response.setTitle(program.getTitle());
        response.setDescription(program.getDescription());
        response.setStartDate(program.getStartDate());
        response.setEndDate(program.getEndDate());
        response.setBudget(program.getBudget());
        response.setStatus(program.getStatus());
        return response;
    }

    private ResourceResponse mapToResourceResponse(Resource resource) {
        ResourceResponse response = new ResourceResponse();
        response.setResourceId(resource.getResourceId());
        if (resource.getProgram() != null) {
            response.setProgramId(resource.getProgram().getProgramId());
        }
        response.setType(resource.getType());
        response.setQuantity(resource.getQuantity());
        response.setStatus(resource.getStatus());
        return response;
    }
}