package com.tourismgov.service;

import com.tourismgov.dto.HeritageSiteRequest;
import com.tourismgov.dto.NotificationRequestDTO; 
import com.tourismgov.dto.PreservationActivityRequest;
import com.tourismgov.enums.NotificationCategory; 
import com.tourismgov.model.HeritageSite;
import com.tourismgov.model.PreservationActivity;
import com.tourismgov.model.User;
import com.tourismgov.repository.HeritageSiteRepository;
import com.tourismgov.repository.PreservationActivityRepository;
import com.tourismgov.repository.UserRepository;
import com.tourismgov.security.SecurityService; 
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Slf4j
@Service
@Transactional(readOnly = true)
public class HeritageSiteServiceImpl implements HeritageSiteService {

    private final HeritageSiteRepository siteRepository;
    private final PreservationActivityRepository activityRepository;
    private final UserRepository userRepository;
    private final NotificationService notificationService; 
    private final SecurityService securityService; 

    public HeritageSiteServiceImpl(HeritageSiteRepository siteRepository, 
                                   PreservationActivityRepository activityRepository,
                                   UserRepository userRepository,
                                   NotificationService notificationService,
                                   SecurityService securityService) {
        this.siteRepository = siteRepository;
        this.activityRepository = activityRepository;
        this.userRepository = userRepository;
        this.notificationService = notificationService;
        this.securityService = securityService;
    }

    // <--- Site Management --->

    @Override
    @Transactional
    public HeritageSite createSite(HeritageSiteRequest request) {
        HeritageSite site = new HeritageSite();
        site.setName(request.getName());
        site.setLocation(request.getLocation());
        site.setDescription(request.getDescription());
        // Set to ACTIVE by default so Dashboard queries count it immediately
        site.setStatus("ACTIVE"); 
        
        HeritageSite saved = siteRepository.save(site);

        // --- GLOBAL NOTIFICATION: WRAPPED IN TRY-CATCH TO PREVENT ROLLBACK ---
        try {
            Long actorId = securityService.getCurrentUserId();
            
            if (actorId != null) {
                notificationService.sendGlobalNotification(NotificationRequestDTO.builder()
                        .userId(actorId) 
                        .entityId(saved.getSiteId())
                        .subject("New Heritage Site Discovered!")
                        .message("We have added a new site: " + saved.getName() + " in " + saved.getLocation() + ". Come visit soon!")
                        .category(NotificationCategory.ANNOUNCEMENT)
                        .build());
            } else {
                log.warn("Notification skipped: No authenticated user found in Security Context.");
            }
        } catch (Exception e) {
            // If email fails, we log it but DO NOT throw the exception.
            // This allows the HeritageSite to stay committed in the database.
            log.error("NON-CRITICAL FAILURE: Site created but global notification failed. Reason: {}", e.getMessage());
        }

        return saved;
    }

    @Override
    @Transactional
    public HeritageSite updateSite(Long siteId, HeritageSiteRequest request) {
        HeritageSite site = getSiteById(siteId);
        site.setName(request.getName());
        site.setLocation(request.getLocation());
        site.setDescription(request.getDescription());
        
        if (request.getStatus() != null && !request.getStatus().isBlank()) {
            site.setStatus(request.getStatus().toUpperCase());
        }
        
        HeritageSite updated = siteRepository.save(site);

        // --- GLOBAL NOTIFICATION: WRAPPED IN TRY-CATCH ---
        try {
            Long actorId = securityService.getCurrentUserId();
            if (actorId != null) {
                notificationService.sendGlobalNotification(NotificationRequestDTO.builder()
                        .userId(actorId)
                        .entityId(updated.getSiteId())
                        .subject("Site Update: " + updated.getName())
                        .message("The heritage site " + updated.getName() + " is now " + updated.getStatus() + ".")
                        .category(NotificationCategory.SYSTEM_UPDATE)
                        .build());
            }
        } catch (Exception e) {
            log.error("NON-CRITICAL FAILURE: Site updated but notification failed: {}", e.getMessage());
        }

        return updated;
    }

    @Override
    @Transactional
    public PreservationActivity logActivity(Long siteId, PreservationActivityRequest request) {
        HeritageSite site = getSiteById(siteId);
        Long currentOfficerId = securityService.getCurrentUserId();
        
        User officer = userRepository.findById(currentOfficerId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Officer not found"));
        
        PreservationActivity activity = new PreservationActivity();
        activity.setSite(site); 
        activity.setOfficer(officer);
        activity.setDescription(request.getDescription());
        activity.setDate(request.getDate());
        activity.setStatus(request.getStatus() != null ? request.getStatus().toUpperCase() : "IN_PROGRESS");
        
        return activityRepository.save(activity);
    }

    @Override
    public List<HeritageSite> getAllSites() {
        return siteRepository.findAll();
    }

    @Override
    public HeritageSite getSiteById(Long siteId) {
        return siteRepository.findById(siteId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, 
                    "Heritage Site not found with ID: " + siteId));
    }

    @Override
    @Transactional
    public void deleteSite(Long siteId) {
        HeritageSite site = getSiteById(siteId);
        siteRepository.delete(site);
    }

    @Override
    public List<PreservationActivity> getActivitiesBySite(Long siteId) {
        getSiteById(siteId);
        return activityRepository.findBySite_SiteId(siteId);
    }

    @Override
    @Transactional
    public void deleteActivity(Long activityId) {
        PreservationActivity activity = activityRepository.findById(activityId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Activity not found"));
        activityRepository.delete(activity);
    }
}