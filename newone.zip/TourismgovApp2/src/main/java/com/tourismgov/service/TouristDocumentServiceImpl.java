package com.tourismgov.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.tourismgov.dto.DocumentUploadRequest;
import com.tourismgov.dto.DocumentVerifyRequest;
import com.tourismgov.dto.NotificationRequestDTO; // ADDED
import com.tourismgov.dto.TouristDocumentResponse;
import com.tourismgov.enums.NotificationCategory; // ADDED
import com.tourismgov.enums.VerificationStatus;
import com.tourismgov.model.Tourist;
import com.tourismgov.model.TouristDocument;
import com.tourismgov.repository.TouristDocumentRepository;
import com.tourismgov.repository.TouristRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class TouristDocumentServiceImpl implements TouristDocumentService {

    private final TouristDocumentRepository documentRepository;
    private final TouristRepository touristRepository;
    private final NotificationService notificationService; // INJECTED

    public TouristDocumentServiceImpl(TouristDocumentRepository documentRepository, 
                                      TouristRepository touristRepository,
                                      NotificationService notificationService) {
        this.documentRepository = documentRepository;
        this.touristRepository = touristRepository;
        this.notificationService = notificationService;
    }

    @Override
    public TouristDocumentResponse verifyDocument(Long touristId, Long documentId, DocumentVerifyRequest request) {
        // 1. Find the document
        TouristDocument doc = documentRepository.findByDocumentIdAndTourist_UserId(documentId, touristId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Document not found for this tourist"));

        try {
            VerificationStatus newStatus = VerificationStatus.valueOf(request.getStatus().toUpperCase());
            doc.setVerificationStatus(newStatus);
            log.info("Document {} verified as {}", documentId, newStatus);
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid status");
        }

        // 2. Save the updated document
        TouristDocument savedDoc = documentRepository.save(doc);

        // --- NOTIFICATION: PRIVATE ALERT TO TOURIST ---
        // Logic: We use .create() because this is for ONE specific user, not everyone.
        notificationService.create(NotificationRequestDTO.builder()
                .userId(touristId) // The Recipient: The tourist who owns the document
                .entityId(savedDoc.getDocumentId())
                .subject("Document Verification Update")
                .message("Your " + savedDoc.getDocType() + " has been marked as " + savedDoc.getVerificationStatus() + ".")
                .category(NotificationCategory.TRANSACTIONAL)
                .build());

        return TouristDocumentResponse.fromEntity(savedDoc);
    }

    // --- OTHER METHODS (uploadDocument, getDocumentMetadata, deleteDocument) REMAIN UNCHANGED ---
    
    @Override
    public TouristDocumentResponse uploadDocument(DocumentUploadRequest dto, Long touristId) {
        Tourist tourist = touristRepository.findById(touristId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Tourist not found"));

        String storedFileUri;
        try {
            if (dto.getFile() != null && !dto.getFile().isEmpty()) {
                String baseUploadDir = new File("uploads").getAbsolutePath();
                String touristFolderPath = Paths.get(baseUploadDir, String.valueOf(touristId)).toString();
                File touristFolder = new File(touristFolderPath);
                if (!touristFolder.exists()) touristFolder.mkdirs();

                String fileName = System.currentTimeMillis() + "_" + dto.getFile().getOriginalFilename().replaceAll("[^a-zA-Z0-9\\.\\-]", "_");
                Path filePath = Paths.get(touristFolderPath, fileName);
                Files.copy(dto.getFile().getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);
                storedFileUri = filePath.toString(); 
            } else if (dto.getFileUri() != null && !dto.getFileUri().isBlank()) {
                storedFileUri = dto.getFileUri();
            } else {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Either file or fileUri must be provided");
            }
        } catch (IOException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Could not save file");
        }

        TouristDocument doc = TouristDocument.builder()
                .tourist(tourist)
                .docType(dto.getDocType())
                .fileUri(storedFileUri)
                .uploadedDate(LocalDateTime.now())
                .verificationStatus(VerificationStatus.PENDING)
                .build();

        return TouristDocumentResponse.fromEntity(documentRepository.save(doc));
    }

    @Override
    public TouristDocumentResponse getDocumentMetadata(Long touristId, Long documentId) {
        TouristDocument doc = documentRepository.findByDocumentIdAndTourist_UserId(documentId, touristId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Document not found"));
        return TouristDocumentResponse.fromEntity(doc);
    }

    @Override
    public void deleteDocument(Long touristId, Long documentId) {
        TouristDocument doc = documentRepository.findByDocumentIdAndTourist_UserId(documentId, touristId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Document not found"));
        try {
            Files.deleteIfExists(Paths.get(doc.getFileUri()));
        } catch (IOException e) {
            log.warn("Physical file not found: {}", e.getMessage());
        }
        documentRepository.delete(doc);
    }
}