package com.tourismgov.service;

import com.tourismgov.dto.CreateEventRequest;
import com.tourismgov.dto.EventResponse;
import com.tourismgov.dto.NotificationRequestDTO; // ADDED
import com.tourismgov.dto.UpdateEventStatusRequest;
import com.tourismgov.enums.NotificationCategory; // ADDED
import com.tourismgov.model.Event;
import com.tourismgov.model.HeritageSite;
import com.tourismgov.repository.EventRepository;
import com.tourismgov.repository.HeritageSiteRepository;
import com.tourismgov.security.SecurityService; // ADDED
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class EventServiceImpl implements EventService {

    private final EventRepository eventRepository;
    private final HeritageSiteRepository siteRepository;
    private final NotificationService notificationService; // INJECTED
    private final SecurityService securityService; // INJECTED
    
    private static final String EVENT_NOT_FOUND = "Event not found";

    @Override
    @Transactional 
    public EventResponse createEvent(CreateEventRequest request) {
        HeritageSite site = siteRepository.findById(request.getSiteId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Site not found"));

        Event event = new Event();
        event.setSite(site);
        event.setTitle(request.getTitle());
        event.setLocation(request.getLocation());
        event.setDate(request.getDate());
        event.setStatus("SCHEDULED");

        Event saved = eventRepository.save(event);

        // --- NOTIFICATION: NEW EVENT BROADCAST ---
        Long actorId = securityService.getCurrentUserId();
        notificationService.sendGlobalNotification(NotificationRequestDTO.builder()
                .userId(actorId) 
                .entityId(saved.getEventId())
                .subject("New Event: " + saved.getTitle())
                .message("A new event has been scheduled at " + site.getName() + " on " + saved.getDate().toLocalDate())
                .category(NotificationCategory.ANNOUNCEMENT)
                .build());

        return mapToResponse(saved);
    }

    @Override
    @Transactional
    public EventResponse updateEventStatus(Long eventId, UpdateEventStatusRequest request) {
        Event event = eventRepository.findById(eventId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, EVENT_NOT_FOUND));
        
        event.setStatus(request.getStatus().toUpperCase());
        Event updated = eventRepository.save(event);

        // --- NOTIFICATION: EVENT STATUS UPDATE ---
        Long actorId = securityService.getCurrentUserId();
        notificationService.sendGlobalNotification(NotificationRequestDTO.builder()
                .userId(actorId)
                .entityId(updated.getEventId())
                .subject("Event Update: " + updated.getTitle())
                .message("The event '" + updated.getTitle() + "' is now " + updated.getStatus())
                .category(NotificationCategory.SYSTEM_UPDATE)
                .build());

        return mapToResponse(updated);
    }

    // --- REMAINING METHODS UNCHANGED ---

    @Override
    public EventResponse getEventById(Long eventId) {
        return eventRepository.findById(eventId)
                .map(this::mapToResponse)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, EVENT_NOT_FOUND));
    }

    @Override
    public List<EventResponse> getAllEvents() {
        return eventRepository.findAll().stream().map(this::mapToResponse).toList();
    }

    @Override
    public List<EventResponse> getEventsBySite(Long siteId) {
        return eventRepository.findBySite_SiteId(siteId).stream().map(this::mapToResponse).toList();
    }
    
    @Override
    @Transactional
    public EventResponse updateEvent(Long eventId, CreateEventRequest request) {
        Event event = eventRepository.findById(eventId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, EVENT_NOT_FOUND));
        event.setTitle(request.getTitle());
        event.setLocation(request.getLocation());
        event.setDate(request.getDate());
        return mapToResponse(eventRepository.save(event));
    }

    @Override
    @Transactional
    public void deleteEvent(Long eventId) {
        Event event = eventRepository.findById(eventId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, EVENT_NOT_FOUND));
        eventRepository.delete(event);
    }

    @Override
    public Page<EventResponse> getEventsPaged(String status, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        return eventRepository.findAll(pageable).map(this::mapToResponse);
    }

    private EventResponse mapToResponse(Event event) {
        EventResponse response = new EventResponse();
        response.setEventId(event.getEventId());
        if (event.getSite() != null) {
            response.setSiteId(event.getSite().getSiteId());
        }
        response.setTitle(event.getTitle());
        response.setLocation(event.getLocation());
        response.setDate(event.getDate());
        response.setStatus(event.getStatus());
        return response;
    }
}