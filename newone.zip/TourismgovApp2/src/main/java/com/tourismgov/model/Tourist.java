package com.tourismgov.model;

import java.time.LocalDate;
import java.util.List;
import com.tourismgov.enums.Gender;
import com.tourismgov.enums.Status;
import jakarta.persistence.*; // Cleaned up imports
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "tourists")
@Getter
@Setter
@NoArgsConstructor
public class Tourist extends BaseEntity {

    @Id
    @Column(name = "user_id") 
    private Long userId;

    @Column(nullable = false)
    private String name;

    private LocalDate dob;
    
    // FIXED: Must specify STRING, otherwise DB expects an Integer
    @Enumerated(EnumType.STRING)
    @Column(length = 20)
    private Gender gender;
    
    private String address;
    private String contactInfo;
    
    // FIXED: Must specify STRING
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Status status = Status.ACTIVE;

    @OneToMany(mappedBy = "tourist", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Booking> bookings;
    
    @OneToMany(mappedBy = "tourist", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<TouristDocument> documents;
    
    @OneToOne(fetch = FetchType.LAZY)
    @MapsId 
    @JoinColumn(name = "user_id") 
    private User user;
}