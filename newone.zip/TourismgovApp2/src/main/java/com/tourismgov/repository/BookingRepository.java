package com.tourismgov.repository;

import com.tourismgov.model.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {

    // THIS IS THE MISSING LINK
    // It tells JPA: Go to the 'tourist' field, then find the 'userId' field inside it.
    List<Booking> findByTourist_UserId(Long userId);

    // If you are using Pagination in your service:
    Page<Booking> findByTourist_UserId(Long userId, Pageable pageable);

    List<Booking> findByEvent_EventId(Long eventId);
    
    Page<Booking> findByEvent_EventId(Long eventId, Pageable pageable);
}