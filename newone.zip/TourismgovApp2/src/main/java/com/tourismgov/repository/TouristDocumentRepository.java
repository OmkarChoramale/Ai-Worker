package com.tourismgov.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tourismgov.model.TouristDocument;

@Repository
public interface TouristDocumentRepository extends JpaRepository<TouristDocument, Long> {

    /**
     * FIXED: Changed 'TouristId' to 'UserId' to match the @MapsId architecture 
     * in the Tourist entity. Spring Data JPA will now correctly traverse:
     * TouristDocument -> Tourist (Entity) -> userId (Field)
     */
    Optional<TouristDocument> findByDocumentIdAndTourist_UserId(Long documentId, Long userId);

    /**
     * Useful for fetching all documents belonging to a specific tourist profile.
     */
  //  List<TouristDocument> findByTourist_UserId(Long userId);
}