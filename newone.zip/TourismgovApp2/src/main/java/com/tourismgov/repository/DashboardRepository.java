package com.tourismgov.repository;

import com.tourismgov.model.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface DashboardRepository extends JpaRepository<Booking, Long> {

    // --- Common ---
    @Query("SELECT COUNT(s) FROM HeritageSite s")
    long countTotalSites();

    @Query("SELECT COUNT(s) FROM HeritageSite s WHERE s.status = 'ACTIVE'")
    long countActiveHeritageSites();

    @Query("SELECT COUNT(e) FROM Event e WHERE e.status = 'ACTIVE'")
    long countActiveEvents();

    @Query("SELECT COALESCE(SUM(p.budget), 0.0) FROM TourismProgram p")
    Double sumTotalProgramBudget();

    @Query("SELECT COUNT(n) FROM Notification n WHERE n.user.userId = :id AND n.status = com.tourismgov.enums.NotificationStatus.UNREAD")
    long countMyUnreadNotifications(@Param("id") Long id);

    // --- Tourist (UPDATED: Changed touristId to userId) ---
    
    @Query("SELECT COUNT(b) FROM Booking b WHERE b.tourist.userId = :id")
    long countTotalBookingHistory(@Param("id") Long id);

    @Query("SELECT COUNT(b) FROM Booking b WHERE b.tourist.userId = :id AND b.status = 'COMPLETED'")
    long countCompletedByUserId(@Param("id") Long id);

    @Query("SELECT COUNT(b) FROM Booking b WHERE b.tourist.userId = :id AND b.status = 'CONFIRMED'")
    long countUpcomingEvents(@Param("id") Long id);

    // --- Internal/Admin ---
    @Query("SELECT COUNT(u) FROM User u WHERE u.status = 'ACTIVE'")
    long countTotalActiveUsers();

    @Query("SELECT COUNT(d) FROM TouristDocument d WHERE d.verificationStatus = com.tourismgov.enums.VerificationStatus.PENDING")
    long countPendingDocValidations();

    @Query("SELECT COUNT(b) FROM Booking b WHERE b.status = 'PENDING'")
    long countPendingBookingApprovals();

    @Query("SELECT COUNT(p) FROM TourismProgram p WHERE p.status = 'ACTIVE'")
    long countActivePrograms();

    @Query("SELECT COUNT(c) FROM ComplianceRecord c WHERE c.result = 'FAIL'")
    long countPolicyViolations();

    @Query("SELECT COUNT(a) FROM Audit a WHERE a.status = 'PENDING'")
    long countPendingAudits();
    
    @Query("SELECT COUNT(e) FROM Event e")
    long countAllEvents();

    @Query("SELECT COUNT(b) FROM Booking b")
    long countAllBookings();

    @Query("SELECT COUNT(u) FROM User u")
    long countAllUsers();
}