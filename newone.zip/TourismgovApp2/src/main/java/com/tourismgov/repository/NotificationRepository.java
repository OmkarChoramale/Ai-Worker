package com.tourismgov.repository;

import com.tourismgov.model.Notification;
import com.tourismgov.enums.NotificationCategory;
import com.tourismgov.enums.NotificationStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface NotificationRepository extends JpaRepository<Notification, Long> {

    // 1. Get all notifications for a specific user
  
    List<Notification> findByUser_UserIdOrderByCreatedDateDesc(Long userId);

    // 2. Get unread alerts for the dashboard
    List<Notification> findByUser_UserIdAndStatusOrderByCreatedDateDesc(
            Long userId, 
            NotificationStatus status
    );

    // 3. Verify notification ownership before marking as read
    Optional<Notification> findByNotificationIdAndUser_UserId(
            Long notificationId, 
            Long userId
    );

   
    long countByUser_UserIdAndStatus(Long userId, NotificationStatus status);

    // 5. Update status manually via JPQL 
    @Modifying
    @Query("UPDATE Notification n SET n.status = :status " +
           "WHERE n.notificationId = :id AND n.user.userId = :userId")
    int updateStatus(
            @Param("status") NotificationStatus status,
            @Param("id") Long id,
            @Param("userId") Long userId
    );
    
    List<Notification> findByUser_UserIdAndCategoryOrderByCreatedDateDesc(
    	    Long userId, 
    	    NotificationCategory category
    	);
}