package com.tourismgov.controller;

import com.tourismgov.dto.ReportRequestDTO;
import com.tourismgov.dto.ReportSummaryDTO;
import com.tourismgov.enums.ReportScope;
import com.tourismgov.service.ReportService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/reports")
@RequiredArgsConstructor
public class ReportController {

    private final ReportService reportService;

    @PostMapping("/generate")
    public ResponseEntity<ReportSummaryDTO> generate(@RequestBody @Valid ReportRequestDTO request) {
        log.info("Request received to generate report for scope: {}", request.getScope());
        
        ReportSummaryDTO response = reportService.generateReport(request);
        
    
        return new ResponseEntity<ReportSummaryDTO>(response, HttpStatus.CREATED);
    }

    @GetMapping("/history")
    public ResponseEntity<List<ReportSummaryDTO>> getHistory(
            @RequestParam Long userId,
            @RequestParam(required = false) ReportScope scope,
            @RequestParam(required = false) @DateTimeFormat(iso = ISO.DATE) LocalDate date) {
        
        List<ReportSummaryDTO> history = reportService.getReportHistory(userId, scope, date);
        return new ResponseEntity<List<ReportSummaryDTO>>(history, HttpStatus.OK);
    }
}