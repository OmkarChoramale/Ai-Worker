package com.tourismgov.dto;

import lombok.Getter;
import lombok.NoArgsConstructor; // CHANGED: Standard for DTOs
import lombok.Setter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import java.time.LocalDateTime;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BookingResponse {
    private Long bookingId;
    
    // CHANGED: Renamed to userId to match the @MapsId architecture
    private Long userId; 
    
    private Long eventId;
    private LocalDateTime date;
    private String status;
}