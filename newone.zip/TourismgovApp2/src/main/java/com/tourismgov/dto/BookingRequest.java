package com.tourismgov.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class BookingRequest {

    @NotNull(message = "User ID is required to identify the tourist")
    private Long userId; // CHANGED: Renamed from touristId to stay consistent with @MapsId

    private String status;
}