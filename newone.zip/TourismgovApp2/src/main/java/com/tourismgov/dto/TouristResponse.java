package com.tourismgov.dto;

import java.time.LocalDate;
import java.util.List;
import com.tourismgov.enums.Gender;
import com.tourismgov.enums.Status;
import com.tourismgov.model.Tourist;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TouristResponse {
    // CHANGED: This is now the User ID from the shared mapping
    private Long userId; 
    private String name;
    private String email; // NEW: Pulled from User entity
    private LocalDate dob;
    private Gender gender;
    private String address;
    private String contactInfo;
    private Status status;
    private List<TouristDocumentResponse> documents;

    public static TouristResponse toResponse(Tourist tourist) {
        if (tourist == null) return null;

        TouristResponse response = new TouristResponse();
        
        // Use the userId from the Tourist entity (which is @MapsId with User)
        response.setUserId(tourist.getUserId());
        
        // Logic: Always prioritize the name in the Tourist profile, 
        // but fall back to the User account name if needed.
        response.setName(tourist.getName());
        
        // NEW: Accessing the parent User object for shared data
        if (tourist.getUser() != null) {
            response.setEmail(tourist.getUser().getEmail());
        }

        response.setDob(tourist.getDob());
        response.setGender(tourist.getGender());
        response.setAddress(tourist.getAddress());
        response.setContactInfo(tourist.getContactInfo());
        response.setStatus(tourist.getStatus());

        if (tourist.getDocuments() != null) {
            response.setDocuments(
                tourist.getDocuments().stream()
                    .map(TouristDocumentResponse::fromEntity)
                    .toList()
            );
        }
        return response;
    }
}