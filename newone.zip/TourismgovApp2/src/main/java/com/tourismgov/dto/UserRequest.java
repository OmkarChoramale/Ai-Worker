package com.tourismgov.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserRequest {
    
    // Optional for Creation, Required for Updates
    private Long userId;
    
    @NotBlank(message = "Name is required")
    @Size(max = 100, message = "Name must be under 100 characters")
    private String name;

    @NotBlank(message = "Role is required (e.g., ADMIN, OFFICER, TOURIST)")
    private String role;

    @NotBlank(message = "Email is required")
    @Email(message = "Please provide a valid email address")
    @Size(max = 150)
    private String email;

    @NotBlank(message = "Password is required")
    @Size(min = 6, message = "Password must be at least 6 characters")
    private String password;

    @Size(max = 15, message = "Phone number is too long")
    private String phone;

    // Defaulted to ACTIVE in the entity, but can be passed here
    private String status;

    // --- ADDED NEW FIELDS TO MATCH POSTMAN REQUEST ---
    private String address;
    
    private String dob; // Format: YYYY-MM-DD
    
    private String gender; // MALE, FEMALE
    
    private String nationality;
    
    private String passportNumber;
}