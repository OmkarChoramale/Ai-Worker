package com.tourismgov.security;

import com.tourismgov.repository.UserRepository;
import com.tourismgov.model.User;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
@RequiredArgsConstructor
public class SecurityService {

    private final UserRepository userRepository;

    public Long getCurrentUserId() {
        // 1. Get the Authentication object safely
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        // 2. Check if it's null or if the user isn't actually authenticated
        if (authentication == null || !authentication.isAuthenticated()) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "No active login session found");
        }

        // 3. Get the email (principal)
        String email = authentication.getName();

        // 4. Find their ID from the database
        return userRepository.findByEmail(email)
                .map(User::getUserId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found in system"));
    }
}